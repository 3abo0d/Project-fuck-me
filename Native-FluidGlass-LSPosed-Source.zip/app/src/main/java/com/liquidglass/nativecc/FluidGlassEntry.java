package com.liquidglass.nativecc;

import android.content.Context;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public final class FluidGlassEntry implements IXposedHookLoadPackage {
    private static final String TAG = "LiquidGlassCC-Native";

    private static final String UTILS =
        "com.oplusos.systemui.common.util.FluidGlassUtils";
    private static final String SUPPLIER =
        "com.oplusos.systemui.common.util.FluidGlassUtils$$ExternalSyntheticLambda0";
    private static final String FEATURE =
        "com.oplus.deviceplugin.sdk.utils.FluidGlassFeature";
    private static final String OBSERVER =
        "com.oplus.systemui.qs.fluidglass.FluidGlassSettingsObserver";
    private static final String HIGHLIGHT_PROXY =
        "com.oplus.systemui.qs.base.widget.QsHighlightTileViewBackgroundProxyImpl";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!"com.android.systemui".equals(lpparam.packageName)) return;

        final ClassLoader cl = lpparam.classLoader;
        log("Loaded in SystemUI: " + lpparam.processName);

        // The support supplier is Kotlin Function0: invoke() has ZERO parameters
        // and returns Object (Boolean). This is the exact signature in this build.
        hookSafely("zero-arg Function0 support supplier", () ->
            XposedHelpers.findAndHookMethod(
                SUPPLIER, cl, "invoke",
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        p.setResult(Boolean.TRUE);
                        log("Support supplier invoke() -> true");
                    }
                }
            )
        );

        // The lazy wrapper is also guarded. This avoids depending on when Lazy
        // first evaluates its supplier during SystemUI startup.
        hookSafely("FluidGlassUtils.isSupported", () ->
            XposedHelpers.findAndHookMethod(
                UTILS, cl, "isSupported",
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        p.setResult(Boolean.TRUE);
                        log("FluidGlassUtils.isSupported() -> true");
                    }
                }
            )
        );

        // Device-plugin path has a second eligibility method.
        hookSafely("FluidGlassFeature.isFluidGlassEnabled", () ->
            XposedHelpers.findAndHookMethod(
                FEATURE, cl, "isFluidGlassEnabled",
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        p.setResult(Boolean.TRUE);
                        log("FluidGlassFeature.isFluidGlassEnabled() -> true");
                    }
                }
            )
        );

        // The setting reader returns a decoded bit (not the raw provider value).
        // Returning 1 means the Fluid Glass bit is enabled regardless of split-QS
        // bit position; this does not write to the user's settings database.
        hookSafely("FluidGlass setting bit reader", () ->
            XposedHelpers.findAndHookMethod(
                OBSERVER, cl, "getShowFluidGlassSwitchState",
                Context.class,
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        p.setResult(1);
                        log("getShowFluidGlassSwitchState() -> 1");
                    }
                }
            )
        );

        // Initial observer registration only populates fluidGlassState. It does
        // not itself call setFluidGlassEnabled(), so synchronize the native cache.
        hookSafely("FluidGlass observer registration", () ->
            XposedHelpers.findAndHookMethod(
                OBSERVER, cl, "onRegister",
                Context.class,
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        enableNativeCache(cl, "observer onRegister");
                    }
                }
            )
        );

        // Keep the native cached flag consistent when the observer later changes.
        hookSafely("FluidGlassUtils.setFluidGlassEnabled", () ->
            XposedHelpers.findAndHookMethod(
                UTILS, cl, "setFluidGlassEnabled",
                boolean.class,
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        enableNativeCache(cl, "setFluidGlassEnabled");
                    }
                }
            )
        );

        // Diagnostic only: this is the real native highlight-tile selector.
        // It branches on FluidGlassUtils.cachedEnabled and constructs the
        // native NormalColorHighLightTileViewFluidGlassBackground.
        hookSafely("native highlight background selector", () ->
            XposedHelpers.findAndHookMethod(
                HIGHLIGHT_PROXY, cl, "getNormalTileViewBackground",
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        Object result = p.getResult();
                        log("getNormalTileViewBackground -> " +
                            (result == null ? "null" : result.getClass().getName()));
                    }
                }
            )
        );

        hookSafely("native target background selector diagnostic", () ->
            XposedBridge.hookAllMethods(
                XposedHelpers.findClass(HIGHLIGHT_PROXY, cl),
                "getTargetQsViewBackground",
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        Object result = p.getResult();
                        log("getTargetQsViewBackground -> " +
                            (result == null ? "null" : result.getClass().getName()));
                    }
                }
            )
        );

        // Prime the native cached flag after the relevant class is loaded.
        hookSafely("prime native cache", () -> enableNativeCache(cl, "SystemUI load"));
    }

    private static void enableNativeCache(ClassLoader cl, String source) {
        try {
            Class<?> utils = XposedHelpers.findClass(UTILS, cl);
            XposedHelpers.setStaticBooleanField(utils, "cachedEnabled", true);
            log("cachedEnabled=true (" + source + ")");
        } catch (Throwable t) {
            log("Could not set cachedEnabled (" + source + "): " + t);
        }
    }

    private interface HookAction { void run() throws Throwable; }

    private static void hookSafely(String name, HookAction action) {
        try {
            action.run();
            log("Hook installed: " + name);
        } catch (Throwable t) {
            log("Hook unavailable: " + name + " :: " + t);
        }
    }

    private static void log(String message) {
        XposedBridge.log("[" + TAG + "] " + message);
    }
}
