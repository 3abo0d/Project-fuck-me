# Native Fluid Glass LSPosed module — CPH2781 / ColorOS 16

This is a **source project**. It is not an APK until GitHub Actions successfully builds it.
It is an LSPosed APK project, not a KernelSU module ZIP.

## Scope and safety

- The entry point immediately returns unless the loaded package is exactly `com.android.systemui`.
- It does not patch or replace `/system_ext/priv-app/SystemUI/SystemUI.apk`.
- All changes are runtime LSPosed hooks and disappear when the module is disabled.
- The first test targets OPPO's existing native Fluid Glass code and background selector.
- The custom LiquidGlassCC panel is not part of this milestone.

## Hooks

- Correct zero-argument `FluidGlassUtils$$ExternalSyntheticLambda0.invoke(): Object`
  Kotlin `Function0` supplier.
- `FluidGlassUtils.isSupported(): boolean`.
- `FluidGlassFeature.isFluidGlassEnabled(): boolean`.
- `FluidGlassSettingsObserver.getShowFluidGlassSwitchState(Context): int`.
- `FluidGlassSettingsObserver.onRegister(Context): void`.
- `FluidGlassUtils.setFluidGlassEnabled(boolean): void`.
- Diagnostic hooks on the existing highlight tile background selector.

The settings reader hook returns the already-decoded enable bit; it does not write
to Secure/System settings. The native `cachedEnabled` field is set at runtime only.

## Build

GitHub Actions workflow: **Build Native Fluid Glass LSPosed APK**.

1. Put this project at the repository root (or copy its files into the existing repo).
2. Open Actions.
3. Run **Build Native Fluid Glass LSPosed APK**.
4. Download artifact `Native-FluidGlass-LSPosed-APK`.
5. The APK inside the artifact is `app-debug.apk`.

Do not upload this source ZIP to KernelSU Manager.

## Install / test

1. Install `app-debug.apk` normally using Android's package installer.
2. Open LSPosed Manager → Modules.
3. Enable **Native Fluid Glass Enabler**.
4. Scope it to **System UI only** (`com.android.systemui`).
5. Restart SystemUI using your normal safe restart method.
6. Expand Quick Settings and inspect tile backgrounds.
7. For diagnostics, inspect LSPosed logs for tag `LiquidGlassCC-Native`.

If SystemUI becomes unstable, disable this module in LSPosed and restart SystemUI.
Do not remove or replace the stock SystemUI APK.

## Important validation status

The source is generated from the supplied ColorOS 16.0.5 / SystemUI 16.00.14
DEX investigation. It has **not** been compiled or tested on the device yet.
The GitHub Actions artifact must exist before calling it a built APK.

A hook may log `Hook unavailable` if OPPO's runtime class loader exposes a
different signature than the supplied DEX dump. Preserve those logs for the next
revision rather than guessing additional methods.
